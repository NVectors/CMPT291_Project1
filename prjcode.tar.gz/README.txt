Group Members:

Name: Nebye Berhe
CCID: berhe

Name: Tristan Carlson
CCID: tcarlson

Name: Victor Nguyen
CCID: victor3 

We did not collaborate with anyone else.

Sources of information:
Notes from Lectures/Labs powerpoints
From https://doc.qt.io/qtforpython/:
  a)https://doc.qt.io/qtforpython/PySide2/QtWidgets/index.html#module-PySide2.QtWidgets
  b)https://doc.qt.io/qt-5/qdialog.html
  c)https://doc.qt.io/qt-5/qlistwidget.html
Converting .ui to .py
  a)https://pypi.org/project/ui-to-py/
